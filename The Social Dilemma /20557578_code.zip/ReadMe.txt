First Run Final in Jupyter cell by cell
then run Binary_classficaition in google Colab cell by cell


YouTube link: https://youtu.be/ZgsfceAYnNc